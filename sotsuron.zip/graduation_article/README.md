# 卒業論文
卒論用のリポジトリ
- main : メインのlatexファイル
- lst.sty : 読み込むスタイルファイル一覧を書き込んだstyファイル（個人的な設定も多い）
- number_section.tex : 分割コンパイルのためのファイルたち
- fig : figureを入れる場所
- bib : bibliography用のbibtexファイル置き場
